package codigo;
import java.util.ArrayList;
import java.util.List;

	class CarrinhoCompras {
	    private List<ItemPedido> itens;

	    public CarrinhoCompras() {
	        this.itens = new ArrayList<>();
	    }

	    public List<ItemPedido> getItens() {
	        return itens;
	    }

	    public void adicionarItem(ItemPedido item) {
	        itens.add(item);
	    }
	}

