package codigo;

public class Main {
	 public static void main(String[] args) {
	        Cliente cliente1 = new Cliente(1, "Lalinha", "Lalinha@email.com");
	        Produto produto1 = new Produto(1, "Bone", 50.99);
	        ItemPedido item1 = new ItemPedido(produto1, 5);
	        CarrinhoCompras carrinho = new CarrinhoCompras();
	        carrinho.adicionarItem(item1);

	        System.out.println("Cliente: " + cliente1.getNome());
	        System.out.println("Item: " + produto1.getNome());
	        System.out.println("Quantidade: " + item1.getQuantidade());
	        System.out.println("Subtotal: " + item1.getSubtotal());
	    }
	}

